export interface User {
  id: string;
  username: string;
  email: string;
  dob?: string;
  image?: string;
  country?: string;
}
 