-- AlterTable
ALTER TABLE "EventTicket" ALTER COLUMN "ticket_price" SET DATA TYPE TEXT,
ALTER COLUMN "available_quantity" SET DATA TYPE TEXT,
ALTER COLUMN "total_quantity" SET DATA TYPE TEXT;
