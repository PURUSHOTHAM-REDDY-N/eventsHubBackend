-- AlterTable
ALTER TABLE "EventTicket" ALTER COLUMN "ticket_price" DROP NOT NULL;
